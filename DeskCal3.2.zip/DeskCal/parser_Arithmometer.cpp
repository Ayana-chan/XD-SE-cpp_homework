#include "parser.h"
#include "error.h"

using namespace Parser_Arithmometer;
using namespace Parser_BasicReader;
using namespace Error;

//These three functions execute each other,so they need statement first.
//Here using namespace is enough.

//handle + -
double Parser_Arithmometer::expr(bool get) {//TIPS:calculation should start by expr(false).
    //'left' is the value of the formula that have been calculated.
    double left = term(get);//get the first (part of formula's) value.
    for (;;) {
        switch (curr_tok) {
            //reason to execute term:
            // if next calculate is * or / , do * or / first.
            case PLUS:
                left += term(true);
                break;
            case MINUS:
                left -= term(true);
                break;
            default:
                return left;//Return the value of the formula that has been calculated (as answer).
        }
    }
}
//handle * /
double Parser_Arithmometer::term(bool get) {
    double left = prim(get);//get value of defined type from prim().
    for (;;) {
        switch (curr_tok) {
            //reason to execute prim:
            // if next calculate is + or - ,
            // instead of do that immediately (which is wrong),
            // we should check the "()".
            case MUL:
                left *= prim(true);
                break;
            case DIV:
                if (double d = prim(true)) {//false only when d=0.
                    left /= d;
                    break;
                }
                return error("divide by 0");
            default:
                return left;//Return the value of the formula that has been calculated
        }
    }
}
//handle primaries
double Parser_Arithmometer::prim(bool get) {
    if (get)
        get_token();//the next value wouldn't be read here,unless the next formula is independent(highest priority).
    switch (curr_tok) {
        case NUMBER: { //floating-point constant
            double v = number_value;
            get_token();
            return v;
        }
        case NAME: {
            double &v = table[string_value];
            if (get_token() == ASSIGN)
                v = expr(true);//Calculate the NAME v's value.
            return v;
        }
        case MINUS: { //unary minus (example:'-' in "-114514")
            return -prim(true);//return negative value
        }
        case LP: { //handle "()"
            double e = expr(true);//calculate the formula in this "()"
            //If formula in "()" have no any error,the next char should be ")" exactly.
            if (curr_tok != RP)
                return error("')' expected");
            get_token();//eat ')'
            return e;
        }
        default:
            return error("primary expected");
    }
}


